// Firebase config (RTDB) - Fleteros
window.FIREBASE_CONFIG = {
  apiKey: "AIzaSyBW6R9IguNRr5WLtsTTKY6eo0rkCpkKcL0",
  authDomain: "testeoappflete.firebaseapp.com",
  projectId: "testeoappflete",
  storageBucket: "testeoappflete.firebasestorage.app",
  messagingSenderId: "100452994973",
  appId: "1:100452994973:web:71b2baa00ead371fcd6974",
  databaseURL: "https://testeoappflete-default-rtdb.firebaseio.com/"
};
