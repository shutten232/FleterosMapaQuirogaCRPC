# Prueba local (sin Firebase)

Para que Panel y Fletero compartan datos, abrilo con servidor local (http://localhost), no con file://.

## Python
En la carpeta del proyecto:
python -m http.server 8000

Abrir:
http://localhost:8000/

## VSCode
Extensión Live Server -> Go Live
